1. For question 1 awk command using pattern matching is applied
2. For question 2 awk command is used which is used to sum the last columns
3. For running the script use "sh Filename.sh"