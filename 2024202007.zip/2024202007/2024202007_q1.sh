
awk 'BEGIN{IGNORECASE=1} /POST/&&/404/{print $0}' access.log



